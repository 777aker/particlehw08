// not included in their git but I'm including so I can use it
#ifndef PERLIN_H
#define PERLIN_H

#include <stdio.h>
#include <math.h>

float perlin2d(float x, float y, float freq, int depth);

#endif